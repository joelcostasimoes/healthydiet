<?php
require_once APPPATH . 'models/App_model.php';
class Address_model extends App_model {
    var $id_user;
    var $address;
    var $zipFnumber;
    var $zipSnumber;
    var $city;
    var $zipName;
    var $country;
    var $type;

    public function __construct($id_user="", $address="", $zipFnumber="", $zipSnumber="", $city="", $zipName="", $country="Portugal", $type="F") {
        $this->id_user=$id_user;
        $this->address=$address;
        $this->zipFnumber=$zipFnumber;
        $this->zipSnumber=$zipSnumber;
        $this->city=$city;
        $this->zipName=$zipName;
        $this->country=$country;
        $this->type=$type;
    }
}

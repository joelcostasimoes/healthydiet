<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . 'models/App_model.php';

class Account_model extends App_model {

    public function __construct() {
        parent::__construct();
        $this->tableName = "user";
        $this->config = array(
            array(
                'field' => 'fname',
                'label' => 'Nome',
                'rules' => 'trim|required|xss_clean|max_length[150]'
            ),
            array(
                'field' => 'lname',
                'label' => 'Apelido',
                'rules' => 'trim|required|xss_clean|max_length[150]'
            ),
            array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'trim|required|xss_clean|valid_email|max_length[80]|is_unique[user.email]'
            ),
            array(
                'field' => 'password',
                'label' => 'Password',
                'rules' => 'trim|required|xss_clean|max_length[150]|matches[cpassword]|sha1'
            ),
            array(
                'field' => 'cpassword',
                'label' => 'Confirmar Password',
                'rules' => 'trim|required|xss_clean|max_length[150]'
            ),
            array(
                'field' => 'nif',
                'label' => 'Número de Identificação Fiscal',
                'rules' => 'trim|required|xss_clean|min_length[9]|max_length[9]|numeric'
            ),
            array(
                'field' => 'phone',
                'label' => 'Telefone',
                'rules' => 'trim|min_length[9]|max_length[11]|numeric'
            ),
            array(
                'field' => 'mobile',
                'label' => 'Telemóvel',
                'rules' => 'trim|min_length[9]|max_length[11]|numeric'
            ),
            array(
                'field' => 'faddress',
                'label' => 'Morada de Faturação',
                'rules' => 'trim|required|xss_clean|min_length[3]|max_length[300]'
            ),
            array(
                'field' => 'fzipFnumber',
                'label' => 'Codigo de Postal',
                'rules' => 'trim|required|xss_clean|min_length[4]|max_length[4]|numeric'
            ),
            array(
                'field' => 'fzipSnumber',
                'label' => 'Codigo de Postal',
                'rules' => 'trim|required|xss_clean|min_length[3]|max_length[3]|numeric'
            ),
            array(
                'field' => 'fzipName',
                'label' => 'Concelho',
                'rules' => 'trim|required|xss_clean|max_length[100]'
            ),
            array(
                'field' => 'fcity',
                'label' => 'Localidade',
                'rules' => 'trim|required|xss_clean|max_length[100]'
            ),
            array(
                'field' => 'terms',
                'label' => 'Termos e Condiçoes',
                'rules' => 'trim|required|xss_clean'
            )
        );
        $this->config_aux = array(
            array(
                'field' => 'eaddress',
                'label' => 'Morada de Entrega',
                'rules' => 'trim|required|xss_clean|min_length[3]|max_length[300]'
            ),
            array(
                'field' => 'ezipFnumber',
                'label' => 'Codigo de Postal de Entrega',
                'rules' => 'trim|required|xss_clean|min_length[4]|max_length[4]|numeric'
            ),
            array(
                'field' => 'ezipSnumber',
                'label' => 'Codigo de Postal de Entrega',
                'rules' => 'trim|required|xss_clean|min_length[3]|max_length[3]|numeric'
            ),
            array(
                'field' => 'ezipName',
                'label' => 'Concelho Entrega',
                'rules' => 'trim|required|xss_clean|max_length[100]'
            ),
            array(
                'field' => 'ecity',
                'label' => 'Localidade de Entrega',
                'rules' => 'trim|required|xss_clean|max_length[100]'
            )
        );
        $this->config_update_my_account = array(
            array(
                'field' => 'fname',
                'label' => 'Nome',
                'rules' => 'trim|xss_clean|max_length[150]'
            ),
            array(
                'field' => 'lname',
                'label' => 'Apelido',
                'rules' => 'trim|xss_clean|max_length[150]'
            ),
            array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'trim|xss_clean|valid_email|max_length[80]'
            ),
            array(
                'field' => 'password',
                'label' => 'Password',
                'rules' => 'trim|xss_clean|max_length[150]|matches[cpassword]|sha1'
            ),
            array(
                'field' => 'cpassword',
                'label' => 'Confirmar Password',
                'rules' => 'trim|xss_clean|max_length[150]'
            ),
            array(
                'field' => 'nif',
                'label' => 'Número de Identificação Fiscal',
                'rules' => 'trim|xss_clean|min_length[9]|max_length[9]|numeric'
            ),
            array(
                'field' => 'phone',
                'label' => 'Telefone',
                'rules' => 'trim|min_length[9]|max_length[11]|numeric'
            ),
            array(
                'field' => 'mobile',
                'label' => 'Telemóvel',
                'rules' => 'trim|min_length[9]|max_length[11]|numeric'
            ),
            array(
                'field' => 'faddress',
                'label' => 'Morada de Faturação',
                'rules' => 'trim|xss_clean|min_length[3]|max_length[300]'
            ),
            array(
                'field' => 'fzipFnumber',
                'label' => 'Codigo de Postal',
                'rules' => 'trim|xss_clean|min_length[4]|max_length[4]|numeric'
            ),
            array(
                'field' => 'fzipSnumber',
                'label' => 'Codigo de Postal',
                'rules' => 'trim|xss_clean|min_length[3]|max_length[3]|numeric'
            ),
            array(
                'field' => 'fzipName',
                'label' => 'Concelho',
                'rules' => 'trim|xss_clean|max_length[100]'
            ),
            array(
                'field' => 'fcity',
                'label' => 'Localidade',
                'rules' => 'trim|xss_clean|max_length[100]'
            ),
            array(
                'field' => 'eaddress',
                'label' => 'Morada de Entrega',
                'rules' => 'trim|xss_clean|min_length[3]|max_length[300]'
            ),
            array(
                'field' => 'ezipFnumber',
                'label' => 'Codigo de Postal de Entrega',
                'rules' => 'trim|xss_clean|min_length[4]|max_length[4]|numeric'
            ),
            array(
                'field' => 'ezipSnumber',
                'label' => 'Codigo de Postal de Entrega',
                'rules' => 'trim|xss_clean|min_length[3]|max_length[3]|numeric'
            ),
            array(
                'field' => 'ezipName',
                'label' => 'Concelho Entrega',
                'rules' => 'trim|xss_clean|max_length[100]'
            ),
            array(
                'field' => 'ecity',
                'label' => 'Localidade de Entrega',
                'rules' => 'trim|xss_clean|max_length[100]' 
            )
        );
    }

    public function getDataUser($id) {
        $condition['id'] = $id;
        $data_user['user'] = $this->find($condition)->row();
        unset($condition);
        $condition = array('id_user' => $id, 'type' => 'F');
        $data_user['faddress'] = $this->find($condition, 'address')->row();
        $condition = array('id' => $id, 'type' => 'E');
        $data_user['eaddress'] = $this->find($condition, 'address')->row();
        unset($data_user['user']->password);
        unset($data_user['user']->status);
        unset($data_user['user']->token);
        unset($data_user['user']->id);
        unset($data_user['faddress']->id_user);
        unset($data_user['faddress']->id);
        unset($data_user['faddress']->type);
        unset($data_user['faddress']->country);
        if ($data_user['eaddress']) {
            $data_user['typeAddress'] = 0;
            unset($data_user['eaddress']->id_user);
            unset($data_user['eaddress']->id);
            unset($data_user['eaddress']->type);
            unset($data_user['eaddress']->country);
        } else {
            $data_user['typeAddress'] = 1;
            $data_user['eaddress'] = null;
        }
        return $data_user;
    }
    public function getDataUserToCheckout($id) {
        $condition['id'] = $id;
        $data_user['user'] = $this->find($condition)->row();
        $condition = array('id_user' => $id, 'type' => 'F');
        $data_user['faddress'] = $this->find($condition, 'address')->row();
        $condition = array('id_user' => $id, 'type' => 'E');
        $data_user['eaddress'] = $this->find($condition, 'address')->row();
        unset($data_user['user']->password);
        unset($data_user['user']->status);
        unset($data_user['user']->token);
        unset($data_user['faddress']->id_user);
        unset($data_user['faddress']->id);
        unset($data_user['faddress']->type);
        unset($data_user['faddress']->country);
        if ($data_user['eaddress']) {
            $data_user['typeAddress'] = 0;
            unset($data_user['eaddress']->id_user);
            unset($data_user['eaddress']->id);
            unset($data_user['eaddress']->type);
            unset($data_user['eaddress']->country);
        } else {
            $data_user['eaddress']= new stdClass();
            $data_user['eaddress']->address = $data_user['faddress']->address;
            $data_user['eaddress']->zipFnumber = $data_user['faddress']->zipFnumber;
            $data_user['eaddress']->zipSnumber = $data_user['faddress']->zipSnumber;
            $data_user['eaddress']->zipName = $data_user['faddress']->zipName;
            $data_user['eaddress']->city = $data_user['faddress']->city;
        }
        return $data_user;
    }

    public function getMyOrders($id, $status) {
        $result_query = $this->db->select('orders.id, orders.more_info, orders.cod_order, orders.date, round(sum(orders_products.price * orders_products.quantity),2) as sum_price')
                ->from('orders')
                ->where('orders.id_user', $id)
                ->where('orders.status', $status)
                ->where('orders.exist_pdf', 1)
                ->join('orders_products', 'orders_products.id_order = orders.id')
                ->group_by('orders.id')
                ->get();
        $orders = NULL;
        if ($result_query->num_rows() > 0) {
            $orders = array();
            foreach ($result_query->result() as $row) {
                $order['id'] = $row->id;
                $order['cod_order'] = $row->cod_order;
                $order['date'] = $row->date;
                $order['sum_price'] = $row->sum_price;
                array_push($orders, $order);
            }
        }
        return htmlspecialchars(json_encode($orders));
    }
    public function getMyCard($id) {
        $User = $this->session->userdata('user_logged');
        $field='salePublic';
        if ($User !=null and $User['type']==2) {
            $field='saleRetailer';
        }
        $result_query = $this->db->select('card.idProduct, ROUND((products.price-(products.price*('.$field.'/100))),2) as price, card.quantity, products.name, products.iva')
                ->from('card')
                ->where('card.id_user', $id)
                ->join('products', 'card.idProduct = products.id')
                ->get();
        $card = NULL;

        if ($result_query->num_rows() > 0) {
            $card = array();
            foreach ($result_query->result() as $row) {
                $item['idProduct'] = $row->idProduct;
                $item['price'] = $row->price;
                $item['quantity'] = $row->quantity;
                $item['name'] = $row->name;
                $item['iva'] = $row->iva;
                array_push($card, $item);
            }
        }

        return $card;
    }
    public function getTotalCard($id) {
        $User = $this->session->userdata('user_logged');
        $field='salePublic';
        if ($User !=null and $User['type']==2) {
            $field='saleRetailer';
        }
        $result_query = $this->db->select('sum((ROUND((products.price-(products.price*('.$field.'/100))),2))*card.quantity) as total')
                ->from('card')
                ->where('card.id_user', $id)
                ->join('products', 'card.idProduct = products.id')
                ->get()->row();
        return round($result_query->total, 2);
    }
    public function getSubTotalInMyCard($id) {
        $User = $this->session->userdata('user_logged');
        $field='salePublic';
        if ($User !=null and $User['type']==2) {
            $field='saleRetailer';
        }
        $result_query = $this->db->select(' ROUND((products.price-(products.price*('.$field.'/100))),2) as price, card.quantity')
                ->from('card')
                ->where('card.id_user', $id)
                ->join('products', 'card.idProduct = products.id')
                ->get();
        $sum['sub_total']=0;
        if ($result_query->num_rows() > 0) {
            
            foreach ($result_query->result() as $row) {
                $sum['sub_total'] += $row->price*$row->quantity;
            }
        }
        return htmlspecialchars(json_encode($sum['sub_total']));
    }

}

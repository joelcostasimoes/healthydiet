﻿<!DOCTYPE html>
<html >
    <head>
    </head>
    <body  >
        <div style="display:table;margin:0 auto;width:960px;min-width:960px;background-position:0 0;background-repeat:no-repeat;background-size:100%;padding:3%;border:1px solid #ededed;position:relative;float:left;border-radius:3px;font-family: sans-serif;">
            <div style="display:block;width:100%;">
                <div style="display:block;font-weight:100;font-size:20px;text-align:left;float:left;width:50%" >
                    <div style="display:block;width:320px;margin-bottom:20px;font-weight:100;font-size:20px;">
                        <img src="<?=base_url()?>public/img/logo2.png"  style="margin: 20px;width: 130px;height:auto;"/>
                    </div>
                    <div style="display:block;font-weight:100;text-align:left;float:left;width:40%;">
                        <div style="display:block;width:100%;">
                            <p style="font-family:sans-serif;font-size:11px;line-height:15px;font-weight:100;display:block;margin-bottom:0px">
                                Rua de Santo António Nº100
                            </p>
                            <p style="font-family:sans-serif;font-size:11px;line-height:15px;font-weight:100;display:block;margin-bottom:0px">
                                2435-063 Caxarias - Ourém
                            </p>
                            <p style="font-family:sans-serif;font-size:11px;line-height:15px;font-weight:100;display:block;margin-bottom:0px">
                                Portugal
                            </p>
                        </div>
                    </div>
                    <div style="display:block;float:left;width:60%;font-weight:100;font-size:20px;text-align:left">
                        <div style="display:block;width:100%;">
                            <p style="font-family:sans-serif;font-size:11px;line-height:15px;font-weight:100;display:block;margin-bottom:0px">
                                Tlf. 249 577 777
                            </p>
                            <p style="font-family:sans-serif;font-size:11px;line-height:15px;font-weight:100;display:block;margin-bottom:0px">
                                Tlm. 914561361
                            </p>
                            <p style="font-family:sans-serif;font-size:11px;line-height:15px;font-weight:100;display:block;margin-bottom:0px">
                                geral@healthydiet.pt
                            </p>
                        </div>
                    </div>
                </div>
                <div style="display:block;float:left;width:50%;font-weight:100;font-size:20px;text-align:left">
                    <div style="display:block;width:100%;">
                        <div style="display:block;width:100%;font-weight:100;font-size:20px;text-align:right;margin-top:20px;font-family:sans-serif">
                            <p style="width:45%;text-align: right;display: inline-block; margin: 0px;font-size: 13px;" >Data:</p>
                            <p style="width:50%;text-align: left;display: inline-block;margin: 0px 0px 10px 10px;font-size: 13px;"></p>
                            <p style="width:45%;text-align: right;display: inline-block; margin: 0px;font-size: 13px;" >Nº de Utilizador:</p>
                            <p style="width:50%;text-align: left;display: inline-block;margin: 0px 0px 10px 10px;font-size: 13px;"></p>
                            <p style="width:45%;text-align: right;display: inline-block; margin: 0px;font-size: 13px;" >Nº de Contribuinte:</p>
                            <p style="width:50%;text-align: left;display: inline-block;margin: 0px 0px 10px 10px;font-size: 13px;""></p>
                            <p style="width:45%;text-align: right;display: inline-block; margin: 0px;font-size: 13px;" >Nº de Encomenda:</p>
                            <p style="width:50%;text-align: left;display: inline-block;margin: 0px 0px 10px 10px;font-size: 13px;"></p>
                        </div>
                    </div>
                </div>
                <div style="display:block;float:left;width:100%;font-weight:100;font-size:20px;">
                    <div style="display:block;text-align:left;float:left;width:40%;position:relative;background:#F8F7F6;padding: 3.5%;margin-top: 20px;margin-bottom: 20px;margin-right: 3%;">
                        <p style="font-family:sans-serif;line-height:15px;font-weight:100;font-size:13px">
                            Morada de Entrega:
                        </p>
                        <p style="font-family:sans-serif;line-height:15px;font-weight:100;font-size:13px">
                        </p>
                        <p style="font-family:sans-serif;line-height:15px;font-weight:100;font-size:13px">
                        </p>
                        <p style="font-family:sans-serif;line-height:15px;font-weight:100;font-size:13px">
                        </p>
                    </div>
                    <div style="display:block;width:40%;font-weight:100;font-size:20px;text-align:left;float:left;position:relative;background:#F8F7F6;padding: 3.5%;margin-top: 20px;margin-bottom: 20px;margin-left: 3%" >
                        <p style="font-family:sans-serif;line-height:15px;font-weight:100;font-size:13px">
                            Morada de Faturação:
                        </p>
                        <p style="font-family:sans-serif;line-height:15px;font-weight:100;font-size:13px">
                        </p>
                        <p style="font-family:sans-serif;line-height:15px;font-weight:100;font-size:13px">
                        </p>
                        <p style="font-family:sans-serif;line-height:15px;font-weight:100;font-size:13px">
                        </p>
                    </div>
                </div>
            </div>
            <h2 style="display:block;float: left;width:100%;font-weight:100;font-size:20px;text-align:left">
                Detalhes da Encomenda:
            </h2>
            <div style="display:block;width:100%;;position:relative;margin-bottom:20px;float:left">
                <div style="display:block;width:100%;text-align:left;float: left;margin-top: 20px;background: #F8F7F6;font-size:13px">
                    <table style="width: 100%;border-collapse:collapse;border: 3px solid #000;">
                        <thead>
                            <tr>
                                <th style="border: 1px solid;padding: 0px 5px;text-align:center;">
                                    Codigo do produto
                                </th>
                                <th style="border: 1px solid;padding: 0px 5px;text-align:center;">
                                    Nome
                                </th>
                                <th style="border: 1px solid;padding: 0px 5px;text-align:center;">
                                    Preço
                                </th>
                                <th style="border: 1px solid;padding: 0px 5px;text-align:center;">
                                    Quantidade
                                </th>
                                <th style="border: 1px solid;padding: 0px 5px;text-align:center;">
                                    Total
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                </td>
                                <td style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                </td>
                                <td style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                </td>
                                <td style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                </td>
                                <td style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4" class="last-rows" style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                    Sub-Total:
                                </td>
                                <td style="border: 1px solid;padding: 0px 5px;">
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4" class="last-rows" style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                    Iva 23%:
                                </td>
                                <td style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                   €
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4" class="last-rows" style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                    Total:
                                </td>
                                <td style="border: 1px solid;padding: 0px 5px;height: 30px;vertical-align: middle;">
                                  €
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <h2 style="display:block;float: left;width:100%;font-weight:100;font-size:20px;text-align:left">
                Observações:
            </h2>
            <div style="display:block;width:100%;font-weight:100;font-size:13px;text-align:left;float: left;margin-top: 20px;background: #F8F7F6;">
                <p style="font-family:sans-serif;line-height:15px;font-weight:100;font-size:13px;width: 56%;float: left;display: inline-block;padding: 0px 2%;">
                </p>
                <div style="font-weight:100;width: 34%;float: left;display: inline-block;border-left: 1px solid #ddd;padding: 0px 2%;margin:13px 0px;font-weight:100;font-size:13px;text-align:left">
                <h4 style="margin-top: 0px;">Metodo de Pagamento:</h4>
                <div style="display:block;width:100%;">
       
                </div>
               
                            <div style="display:block;width:100%;">
                                <div style="display:block;width:100%;">
                                    Entidade: 20343
                                </div>
                                <div style="display:block;width:100%;">
                                    Referência: 138 445 742
                                </div>
                                <div style="display:block;width:100%;">
                                    Montante: 100€
                                </div>
                            </div>
                            
                                <div style="display:block;width:100%;">
                                    IBAN: PT50 xxxxxxxxxxxxxxxxxxxxx
                                </div>
                                <div style="display:block;width:100%;">
                                    O pagamento no acto da entrega tem custos adicionais para o cliente.
                                </div>
                     </div>
                
            </div>
            <div style="display:block;width:100%;font-weight:100;font-size:20px;text-align:right;float: left;border-top:1px solid #ddd;margin-top:10px;padding-top:30px;" class="footer">
                <p style="font-family:sans-serif;font-size:13px;font-weight:100;text-align:center">
                    <strong style="font-family:sans-serif;font-weight:700">
                        Tlf.
                    </strong>
                    249 790 976 |
                    <strong style="font-family:sans-serif;font-weight:700">
                        Tlm.
                    </strong>
                    918 748 068 |
                    <strong style="font-family:sans-serif;font-weight:700">
                        Tlm.
                    </strong>
                    912 981 019
                </p>
                <p style="font-family:sans-serif;font-size:13px;font-weight:100;text-align:center">
                    <a href="www.healthydiet.pt" target="_blank"  style="text-decoration:none;color:#e82583">
                        www.healthydiet.pt
                    </a>
                    |
                    <a href="" style="text-decoration:none;color:#e82583">
                        geral@healthydiet.pt
                    </a>
                    |
                    <a href="www.facebook.com/dietistaodete/" >
                        facebook.com/healthydiet
                    </a>
                </p>
            </div>
        </div>
    </body>
</html>

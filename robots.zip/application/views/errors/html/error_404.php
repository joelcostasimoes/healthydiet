<div class="single-product-area">
    <div class="error404 container">
    	<h1>Oops!!</h1>
    	<p>A página à qual está a tentar aceder não existe.</p>
    	 <img ng-src="<?=base_url()?>public/img/error2.jpg" alt="">
    </div>
</div>